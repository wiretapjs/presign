
module.exports = (sessions) => {
  return sessions.length === 1
}
