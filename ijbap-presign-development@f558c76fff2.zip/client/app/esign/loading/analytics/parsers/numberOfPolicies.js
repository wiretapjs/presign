import policyNumbers from './policyNumbers'

export default function (eSignSessions) {
  return policyNumbers(eSignSessions).length
}
