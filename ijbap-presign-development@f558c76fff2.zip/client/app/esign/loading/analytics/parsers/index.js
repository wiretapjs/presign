import numberOfPolicies from './numberOfPolicies'
import policyNumbers from './policyNumbers'

export default { numberOfPolicies, policyNumbers }
