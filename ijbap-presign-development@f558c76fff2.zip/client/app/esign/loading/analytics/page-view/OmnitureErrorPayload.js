export default class {
  constructor () {
    this.applicationID = 'eSign'
    this.siteSection = 'Policy'
    this.siteCode = 'PM-ES'
    this.TileName = 'esignNoPolicies'
    this.platformTrigram = 'ERW'
    this['confirm.eSign'] = 'eSignNoPolicy'
    this.eSignSession = 'eSignNoPolicy'
    this.eSignDetail = '0'
    this.loginStatus = 'New'
    this.eSignIntent = 'eSign'
  }
}
