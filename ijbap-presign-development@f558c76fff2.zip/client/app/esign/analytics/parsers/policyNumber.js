export default function (session) {
  return session.policyNumber || null
}
