import numberOfSigners from 'app/esign/analytics/parsers/numberOfSigners'
import policyNumber from 'app/esign/analytics/parsers/policyNumber'

export default { numberOfSigners, policyNumber }
