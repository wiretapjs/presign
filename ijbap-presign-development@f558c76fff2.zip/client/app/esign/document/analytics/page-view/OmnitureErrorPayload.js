export default class {
  constructor () {
    this.TileName = 'esignSystemUnavailable'
  }
}
