import styled from 'styled-components'

export const StyledCantseeLinkWrapper = styled.div`
  margin : 10px;
`
