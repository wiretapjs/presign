export default {
  registrationLink: undefined,
  environment: undefined,
  libertySubDomainMapping: undefined,
  visitor: undefined,
}
