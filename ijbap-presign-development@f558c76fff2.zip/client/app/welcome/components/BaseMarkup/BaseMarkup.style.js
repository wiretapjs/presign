import styled from 'styled-components'

export const StyledBottomHeaderText = styled.h3`
`
