export const paperlessTermsAndCondition = 'http://public.libertymutual-cdn.com/PmEService/MediaAssets/pages/terms-and-conditions-enrollment.html'
export const eSignDocuments = '/esign/document'
