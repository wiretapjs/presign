export const termsAndConditionsError = new Error('Failed to accept terms and conditions')
