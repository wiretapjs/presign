import Variant from '../Variant'

export default {
  salt: 'welcome',
  percentBaseVersion: 50,
  base: new Variant('base'),
  treatmentA: new Variant('a'),
}
