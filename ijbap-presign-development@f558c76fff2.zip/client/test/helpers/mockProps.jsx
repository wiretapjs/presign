export const mockHistory = {
  push: jest.fn(),
}
