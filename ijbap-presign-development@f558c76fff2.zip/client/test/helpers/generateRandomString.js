export default function () {
  return Math.random().toString(36).substring(7)
}
