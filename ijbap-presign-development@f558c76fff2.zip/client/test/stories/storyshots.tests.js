import initStoryshots from '@storybook/addon-storyshots'

// Uses stories to test that everything renders correctly
initStoryshots()
