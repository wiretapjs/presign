const DocumentCountService = require('./service')

module.exports = new DocumentCountService()
