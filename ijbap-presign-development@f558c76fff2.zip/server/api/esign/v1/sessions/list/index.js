const v1ListService = require('./service')
module.exports = v1ListService
