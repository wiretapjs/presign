const PolicySummaryService = require('./service')

module.exports = new PolicySummaryService()
