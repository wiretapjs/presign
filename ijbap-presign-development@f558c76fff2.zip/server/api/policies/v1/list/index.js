const PolicyListService = require('./service')

module.exports = new PolicyListService()
