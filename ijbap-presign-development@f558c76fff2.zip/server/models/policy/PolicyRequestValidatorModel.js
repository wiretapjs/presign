class PolicyRequestValidatorModel {
    filters = {
      linesOfBusiness: [],
      ratingMethod: '',
    }
}

module.exports = PolicyRequestValidatorModel
