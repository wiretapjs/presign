module.exports = {
  newrelic: true,
  services: {
    eServiceLegacy: {
      url: 'https://eservice.libertymutual.com',
    },
  },
}
