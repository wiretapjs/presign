module.exports = {
  services: {
    eServiceLegacy: {
      url: 'https://ete-eservice.libertymutual.com',
    },
  },
}
