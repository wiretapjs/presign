module.exports = {
  newrelic: true,
  services: {
    eServiceLegacy: {
      url: 'https://uat-service.libertymutual.com',
    },
  },
}
