module.exports = {
  services: {
    eServiceLegacy: {
      url: 'https://dev-c-service.libertymutual.com',
    },
  },
}
